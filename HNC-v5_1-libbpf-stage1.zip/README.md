# HNC v5.0 → v5.1 libbpf 改造

## 决定原因
beta.4 hotfix1-5 试了 5 轮, 手撸 sys_bpf 在 BPF_BTF_LOAD 死结:
- BTF sanitize (clang 18 BTF kind 跟 ColorOS kernel 不兼容)
- CO-RE 重定位 (.BTF.ext 没处理, task_struct 字段偏移错)
- .rel.BTF 处理 (DATASEC/VAR 的 name_off placeholder 没填)

evaluation AI 推荐: 这些都是 libbpf 的核心职责, 手撸不可行。
直接静态链接 libbpf, 800 行 loader 缩到 380 行, 全部交给 libbpf 处理。

## 文件
- `STAGE-1-prep.md` — 你现在要执行的: 加 git submodules
- `STAGE-2-build-integration.md` — 我下一轮要发: build.sh + CI 改造
- `daemon/hotspotd/lsm/hnc_lsm_loader.c` — libbpf 版 loader, 替换原文件

## 执行顺序
1. 看 STAGE-1-prep.md, 跑 git submodule add
2. 把 daemon/hotspotd/lsm/hnc_lsm_loader.c 拷到对应位置 (覆盖旧版)
3. 把执行结果(submodule status + 文件数量)发给我
4. 我发 Stage 2 patch

## 不要 git push 修改 hotspotd 代码
只 git push submodule 添加。等 Stage 2 patch 一起 push, 否则 CI build
会失败(loader.c 引用的 libbpf 头还没接上)。
